package edu.millersville.csci366.studentslab.ajrios;

public class Student {
    // Fields
    private String id;
    private String name;
    private String departmentName;
    private int totalCreditsCompleted;

    // Constructor
    public Student(String id, String name, String departmentName, int totalCreditsCompleted) {
        this.id = id;
        this.name = name;
        this.departmentName = departmentName;
        this.totalCreditsCompleted = totalCreditsCompleted;
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDeptName() {
        return departmentName;
    }

    public int getTotCredits() {
        return totalCreditsCompleted;
    }

    // Setter methods
    public void setName(String name) {
        this.name = name;
    }

    public void setDeptName(String departmentName) {
        this.departmentName = departmentName;
    }

    public void setTotCredits(int totalCreditsCompleted) {
        this.totalCreditsCompleted = totalCreditsCompleted;
    }
}