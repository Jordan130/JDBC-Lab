package edu.millersville.csci366.studentslab.ajrios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import edu.millersville.csci366.studentslab.startercode.DataException;
import edu.millersville.csci366.studentslab.startercode.DataSource;

/**
 * PostgreSQLDataSource class provides an implementation of the DataSource interface
 * for interacting with a PostgreSQL database containing student information. 
 * It establishes a connection to the database and implements methods to load, 
 * create, update, and delete student records.
 */
public class PostgreSQLDataSource implements DataSource {

    // Define public class constants for connection parameters
    public static final String PROTOCOL = "jdbc:postgresql";
    public static final String HOSTNAME = "csci366.millersville.edu";
    public static final String DATABASE = "a07students_ajrios"; 
    public static final String URL = PROTOCOL + "://" + HOSTNAME + "/" + DATABASE;
    public static final String USERNAME = "ajrios"; 
    public static final String PASSWORD = "Emmatreat18!"; 

    // Field to store a Connection object
    private Connection connection;
    
    // Constructor to initialize the Connection object
    public PostgreSQLDataSource(Connection connection) {
        this.connection = connection;
    }

    // Constructor to initialize the Connection object
    public PostgreSQLDataSource() throws DataException {
        try {
            // Establish the connection
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (SQLException e) {
            // Convert SQLException to DataException
            throw new DataException(e);
        }
    }

    /**
     * Retrieves all students from the database.
     * 
     * @return A map containing student IDs as keys and Student objects as values.
     * @throws DataException If an error occurs while retrieving the students.
     */
    @Override
    public Map<String, Student> loadAllStudents() throws DataException {
        // Initialize a map to store students
        Map<String, Student> students = new HashMap<>();
        // Define the SQL query
        String query = "SELECT id, name, dept_name, tot_cred FROM student";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            // Iterate through the result set
            while (resultSet.next()) {
                // Extract student information from the result set
                String id = resultSet.getString("id");
                String name = resultSet.getString("name");
                String department = resultSet.getString("dept_name");
                int credits = resultSet.getInt("tot_cred");
                // Create a new Student object
                Student student = new Student(id, name, department, credits);
                // Add the student to the map
                students.put(id, student);
            }
        } catch (SQLException e) {
            // Convert SQLException to DataException
            throw new DataException(e);
        }
        return students;
    }

    /**
     * Creates a new student in the database.
     * 
     * @param student The student object to be created.
     * @throws DataException If an error occurs while creating the student.
     */
    @Override
    public void createStudent(Student student) throws DataException {
        // Define the SQL query
        String query = "INSERT INTO student (id, name, dept_name, tot_cred) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            // Set parameters for the prepared statement
            statement.setString(1, student.getId());
            statement.setString(2, student.getName());
            statement.setString(3, student.getDeptName());
            statement.setInt(4, student.getTotCredits());
            // Execute the update
            statement.executeUpdate();
        } catch (SQLException e) {
            // Convert SQLException to DataException
            throw new DataException(e);
        }
    }

    /**
     * Updates an existing student in the database.
     * 
     * @param student The student object with updated information.
     * @throws DataException If an error occurs while updating the student.
     */
    @Override
    public void updateStudent(Student student) throws DataException {
        // Define the SQL query
        String query = "UPDATE student SET name=?, dept_name=?, tot_cred=? WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            // Set parameters for the prepared statement
            statement.setString(1, student.getName());
            statement.setString(2, student.getDeptName());
            statement.setInt(3, student.getTotCredits());
            statement.setString(4, student.getId());
            // Execute the update
            statement.executeUpdate();
        } catch (SQLException e) {
            // Convert SQLException to DataException
            throw new DataException(e);
        }
    }

    /**
     * Deletes a student from the database.
     * 
     * @param student The student object to be deleted.
     * @throws DataException If an error occurs while deleting the student.
     */
    @Override
    public void deleteStudent(Student student) throws DataException {
        // Define the SQL query
        String query = "DELETE FROM student WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            // Set parameters for the prepared statement
            statement.setString(1, student.getId());
            // Execute the update
            statement.executeUpdate();
        } catch (SQLException e) {
            // Convert SQLException to DataException
            throw new DataException(e);
        }
    }
}