package edu.millersville.csci366.studentslab.ajrios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

import edu.millersville.csci366.studentslab.startercode.CSVFileDataSource;
import edu.millersville.csci366.studentslab.startercode.DataException;
import edu.millersville.csci366.studentslab.startercode.DataSource;
import edu.millersville.csci366.studentslab.startercode.StudentController;
import edu.millersville.csci366.studentslab.startercode.StudentModel;
import edu.millersville.csci366.studentslab.startercode.StudentView;
import edu.millersville.csci366.studentslab.startercode.SwingStudentView;

public class Lab07Main {

    public static void main(String[] args) {
        // Create a scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to choose the data source type
        System.out.println("Choose data source type:");
        System.out.println("1. CSV File");
        System.out.println("2. PostgreSQL Database");
        System.out.print("Enter your choice (1 or 2): ");
        int dataSourceChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        DataSource dataSource = null;
        // Path to the CSV file
        String csvFilePath = "data/students.csv";
        try {
            // Establish connection based on user's choice
            if (dataSourceChoice == 1) {
                // Use CSVFileDataSource
                dataSource = new CSVFileDataSource(csvFilePath);
            } else if (dataSourceChoice == 2) {
                Connection connection = DriverManager.getConnection(PostgreSQLDataSource.URL,
                        PostgreSQLDataSource.USERNAME, PostgreSQLDataSource.PASSWORD);
                // Use PostgreSQLDataSource with established connection
                dataSource = new PostgreSQLDataSource(connection);
            } else {
                System.out.println("Invalid choice. Exiting...");
                return;
            }

            // Create StudentModel using chosen data source
            StudentModel studentModel = new StudentModel(dataSource);

            // Choose view type
            System.out.println("Choose view type:");
            System.out.println("1. Swing (Graphical User Interface)");
            System.out.println("2. Console");
            System.out.print("Enter your choice (1 or 2): ");
            int viewType = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Create view based on user's choice
            StudentView studentView = null;
            if (viewType == 1) {
                studentView = new SwingStudentView();
            } else if (viewType == 2) {
                studentView = new ConsoleStudentView();
            } else {
                System.out.println("Invalid choice. Exiting...");
                return;
            }

            // Create StudentController
            StudentController studentController = new StudentController(studentModel, studentView);

            // Run the program
            studentController.run();

        } catch (SQLException e) {
            System.out.println("Error establishing database connection: " + e.getMessage());
        } finally {
            // Close scanner
            if (scanner != null) {
                scanner.close();
            }
        }
    }
}