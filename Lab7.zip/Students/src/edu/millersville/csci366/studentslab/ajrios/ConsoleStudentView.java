package edu.millersville.csci366.studentslab.ajrios;

import java.util.Map;
import java.util.Scanner;

import edu.millersville.csci366.studentslab.startercode.Action;
import edu.millersville.csci366.studentslab.startercode.StudentView;

/**
 * A console-based implementation of the StudentView interface.
 * Allows interaction with students through the console.
 */
public class ConsoleStudentView implements StudentView {

    private Scanner scanner;

    /**
     * Constructs a new ConsoleStudentView object with a Scanner for user input.
     */
    public ConsoleStudentView() {
        scanner = new Scanner(System.in);
    }

    /**
     * Prompts the user to enter details for a new student.
     * 
     * @return The details of the new student as a Student object.
     */
    @Override
    public Student getNewStudentDetails() {
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Department: ");
        String department = scanner.nextLine();
        System.out.print("Credits: ");
        int credits = Integer.parseInt(scanner.nextLine());
        // Assuming ID will be generated automatically in the database
        return new Student(id, name, department, credits);
    }

    /**
     * Prompts the user to enter the ID of the student to delete.
     * 
     * @return The ID of the student to delete.
     */
    @Override
    public String getIdToDelete() {
        System.out.print("Which student (ID) to delete: ");
        return scanner.nextLine();
    }

    /**
     * Prompts the user to enter the ID of the student to edit.
     * 
     * @return The ID of the student to edit.
     */
    @Override
    public String getIdToEdit() {
        System.out.print("Which student (ID) to edit: ");
        return scanner.nextLine();
    }

    /**
     * Allows the user to edit the details of a student.
     * 
     * @param student The student object to edit.
     */
    @Override
    public void editStudent(Student student) {
        System.out.println("Editing student:");
        while (true) {
            System.out.printf("%s | %s | %s | %s\n", student.getId(), student.getName(), student.getDeptName(), student.getTotCredits());
            System.out.print("Select to edit name, department, credits, save, or cancel: ");
            String choice = scanner.nextLine();
            switch (choice.toLowerCase()) {
                case "name":
                    System.out.print("New Name: ");
                    student.setName(scanner.nextLine());
                    break;
                case "department":
                    System.out.print("New Department: ");
                    student.setDeptName(scanner.nextLine()); 
                    break;
                case "credits":
                    System.out.print("New Credits: ");
                    student.setTotCredits(Integer.parseInt(scanner.nextLine()));
                    break;
                case "save":
                    return;
                case "cancel":
                    return;
                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        }
    }

    /**
     * Prompts the user to enter the next action to perform.
     * 
     * @return The Action enum representing the chosen action.
     */
    @Override
    public Action getNextAction() {
        System.out.print("Type one of 'new', 'edit', 'delete', 'refresh', or 'quit': ");
        String action = scanner.nextLine().toLowerCase();
        switch (action) {
            case "new":
                return Action.NEW;
            case "edit":
                return Action.EDIT;
            case "delete":
                return Action.DELETE;
            case "refresh":
                return Action.REFRESH;
            case "quit":
                return Action.QUIT;
            default:
                System.out.println("Invalid action. Please try again.");
                return getNextAction();
        }
    }

    /**
     * Displays all the students in a tabular format.
     * 
     * @param students A map containing student IDs as keys and Student objects as values.
     */
    @Override
    public void showAllStudents(Map<String, Student> students) {
        // Define column widths
        int idWidth = 5;
        int nameWidth = 20;
        int departmentWidth = 20;
        int creditsWidth = 13;

        // Print column headers
        System.out.printf("%-" + idWidth + "s | %-" + nameWidth + "s | %-" + departmentWidth + "s | %-" + creditsWidth + "s\n", "ID", "Name", "Department", "Credits");
        
        // Print separator line
        System.out.println("-".repeat(idWidth + nameWidth + departmentWidth + creditsWidth + 3));

        // Print student information
        for (Student student : students.values()) {
            System.out.printf("%-" + idWidth + "s | %-" + nameWidth + "s | %-" + departmentWidth + "s | %-" + creditsWidth + "d\n",
                    student.getId(), student.getName(), student.getDeptName(), student.getTotCredits());
        }
    }

    /**
     * Notifies the user about a failure to create a student.
     * 
     * @param failedCreation The student object that failed to be created.
     * @param reason The reason for the failure.
     */
    @Override
    public void notifyCreateFailure(Student failedCreation, String reason) {
        System.out.println("Failed to create student: " + failedCreation.getName() + ". Reason: " + reason);
    }

    /**
     * Notifies the user about a failure to delete a student.
     * 
     * @param id The ID of the student that failed to be deleted.
     * @param reason The reason for the failure.
     */
    @Override
    public void notifyDeletionFailure(String id, String reason) {
        System.out.println("Failed to delete student with ID " + id + ". Reason: " + reason);
    }

    /**
     * Notifies the user about a failure to edit a student.
     * 
     * @param id The ID of the student that failed to be edited.
     * @param reason The reason for the failure.
     */
    @Override
    public void notifyEditFailure(String id, String reason) {
        System.out.println("Failed to edit student with ID " + id + ". Reason: " + reason);
    }

    /**
     * Notifies the user about a failure to load students.
     * 
     * @param reason The reason for the failure.
     */
    @Override
    public void notifyLoadFailure(String reason) {
        System.out.println("Failed to load students. Reason: " + reason);
    }
}